//
//  ContentView.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 22.01.2025.
//

import SwiftUI

struct Anasayfa: View {
    @ObservedObject var viewModel = AnasayfaViewModel()
    var body: some View {
        NavigationStack{
            List{
                ForEach(viewModel.yemeklerListesi){yemek in
                    NavigationLink(destination: DetaySayfa(yemek: yemek)){
                        YemekSatir(yemek: yemek)
                    }
                    
                }
            }.navigationTitle("Yemekler")
                .onAppear{
                   
                    viewModel.yemekleriYukle()
                }
        }
    }

}

#Preview {
    Anasayfa()
}
