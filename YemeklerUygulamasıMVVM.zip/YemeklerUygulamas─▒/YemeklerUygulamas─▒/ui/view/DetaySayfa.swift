//
//  DetaySayfa.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 22.01.2025.
//

import SwiftUI

struct DetaySayfa: View {
    var yemek=Yemekler()
    var body: some View {
        VStack(spacing:100){
            Image(yemek.yemek_resim_adi!)
            Text("\(yemek.yemek_fiyat!) TL").font(.system(size: 50)).foregroundStyle(.blue)
            Button("Sipariş Ver"){
                print("Sipariş verildi : \(yemek.yemek_adi!)")
            }.foregroundColor(.white)
                .frame(width: 250,height: 50).background(.blue)
                .cornerRadius(10)
        }.navigationTitle(yemek.yemek_adi!)
    }
}

/*#Preview {
    DetaySayfa()
}*/
