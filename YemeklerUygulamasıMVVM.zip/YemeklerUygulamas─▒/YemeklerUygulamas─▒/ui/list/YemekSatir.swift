//
//  YemekSatir.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 22.01.2025.
//

import SwiftUI

struct YemekSatir: View {
    var yemek=Yemekler()
    var body: some View {
        HStack(){
            Image(yemek.yemek_resim_adi!).resizable().frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/,height: 100)
            VStack(alignment:.leading,spacing: 30){
                Text(yemek.yemek_adi!)
                Text("\(yemek.yemek_fiyat!) TL").foregroundStyle(.blue)
            }
        }
    }
}

//#Preview {
   // YemekSatir()
//}
