//
//  ResultYemekler.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 10.02.2025.
//

import Foundation

class ResultYemekler : Codable{
    var yemekler:[Yemekler]?
    var success:Int?
}
