//
//  YemeklerUygulamas_App.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 22.01.2025.
//

import SwiftUI

@main
struct YemeklerUygulamas_App: App {
    var body: some Scene {
        WindowGroup {
            Anasayfa()
        }
    }
}
