//
//  ContentView.swift
//  YemeklerUygulaması
//
//  Created by Nefise Hazır on 22.01.2025.
//

import SwiftUI

struct Anasayfa: View {
    @ObservedObject var viewModel = AnasayfaViewModel()
    var body: some View {
        NavigationStack{
            List{
                ForEach(viewModel.yemeklerListesi){yemek in
                    NavigationLink(destination: DetaySayfa(yemek: yemek)){
                        YemekSatir(yemek: yemek)
                    }
                    
                }
            }.navigationTitle("Yemekler")
                .onAppear{
                    veriTabanıKopyala()
                    viewModel.yemekleriYukle()
                }
        }
    }
    func veriTabanıKopyala(){
        if let bundlePath = Bundle.main.path(forResource: "yemekler", ofType: "sqlite"){
            let bundleURL=URL(fileURLWithPath: bundlePath)
            let veriTabaniYolu = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            let hedefYol = URL(fileURLWithPath: veriTabaniYolu).appendingPathComponent("yemekler.sqlite")
            
            let fm = FileManager.default
            
            if fm.fileExists(atPath: hedefYol.path) {
                print("veri tabanı var ")
            }else{
                do {
                    try fm.copyItem(at: bundleURL, to: hedefYol)
                } catch  {
                    print(error.localizedDescription)
                }
            }
        }else{
            print("bundle da dosya bulunamadı")
        }
    }
}

#Preview {
    Anasayfa()
}
